%%%Moments of Inertia Cubesat
Ix = 0.9;
Iy = 0.9;
Iz = 0.3;
I = [Ix,0,0;0,Iy,0;0,0,Iz]; %%kg-m^2
invI = inv(I);