%%% Clear workspace
clear
clc
close all

%%%Globals
global BxI ByI BzI BxB ByB BzB

%%% Setup IGRF model

addpath 'igrf/'

%%%Get Earth Parameters for orbit
planet

%%%Cubesat parameters
global m invI I
m = 2.6; %%mass in kilograms
inertia

%%%Initial Conditions Position and Velocity
altitude = 600*1000; %%meters
x0 = R + altitude;
y0 = 0;
z0 = 0; 
xdot0 = 0;
inclination = deg2rad(56);
semi_major = norm([x0;y0;z0]); %%Orbit Radius for circular orbit
vcircular = sqrt(mu/semi_major); %%Orbital Speed from Vis-Viva Equation with a=r
ydot0 = vcircular*cos(inclination);
zdot0 = vcircular*sin(inclination);

%%%Initial Conditions Attitude and Angular velocity
%Initialize Euler Angles
phi0 = 0;
theta0 = 0;
psi0 = 0;
ptp0 = [phi0;theta0;psi0];
q0123_0 = Eu2Quat(ptp0); %Transform to quat initial conditions

%Initial Angular Velocity (Body Frame)
p0=0.01;
q0=0;
r0=0;

%Initial Conditions state vector
stateinitial = [x0;y0;z0;xdot0;ydot0;zdot0;q0123_0;p0;q0;r0];

%%%Orbit time parameters Circular Orbit
period = 2*pi/sqrt(mu)*semi_major^(3/2); %%Tcircular
number_of_orbits = 1;
tfinal = period*number_of_orbits;
tspan = 0:1:tfinal;

%%%This is where we integrate the equations of motion
[tout,stateout] = ode45(@Satellite,tspan,stateinitial);

%%%Loop through stateout to extract Magnetic Field

BxIout=0*stateout(:,1);
ByIout=BxIout;
BzIout=BxIout;

for idx = 1:length(tout)
    dstatedt = Satellite(tout(idx),stateout(idx,:)');
    BxIout(idx)=BxI;
    ByIout(idx)=ByI;
    BzIout(idx)=BzI;
    lin_acc(1:3,idx)= dstatedt(4:6,1);
    BxBout(idx)=BxB;
    ByBout(idx)=ByB;
    BzBout(idx)=BzB;


end


%%%Convert state to kilometers
stateout(:,1:6) = stateout(:,1:6)/1000;

%%%Extract the state vector
xout = stateout(:,1);
yout = stateout(:,2);
zout = stateout(:,3);
q0123out = stateout(:,7:10);
ptpout = Quat2Eu(q0123out);
pqrout = stateout(:,11:13);
%%%Make an Earth
[X,Y,Z] = sphere(100);
X = X*R/1000;
Y = Y*R/1000;
Z = Z*R/1000;

%%%Plot 3D orbit
fig = figure();
set(fig,'color','white')
plot3(xout,yout,zout,'r-','LineWidth',3)
xlabel('X')
ylabel('Y')
zlabel('Z')
grid on
hold on
earth_sphere()
axis equal

%%%Plot Quaternions
fig2 = figure();
set(fig2,'color','white')
plot(tout,q0123out,'-','LineWidth',2);
grid on
xlabel('Time (sec)')
ylabel('Quaternions')
legend('q0','q1','q2','q3')
xlim([0,2000])

%%%Plot Euler Angles
fig3 = figure();
set(fig3,'color','white')
plot(tout,ptpout*180/pi,'-','LineWidth',2);
grid on
xlabel('Time (sec)')
ylabel('Euler Angles (deg)')
legend('Phi','Theta','Psi')

%%%Plot Angular Velocity
fig4 = figure();
set(fig4,'color','white')
plot(tout,pqrout,'-','LineWidth',2);
grid on
xlabel('Time (sec)')
ylabel('Angular Velocity (rad/s)')
legend('p','q','r')


%%%plot the magnetic field
fig5=figure();
set(fig5,'color','white');
plot(tout,BxIout/1000,'b-','Linewidth',2);
hold on
grid on
plot(tout,ByIout/1000,'r-','Linewidth',2);
hold on
plot(tout,BzIout/1000,'g-','Linewidth',2);
xlabel('Time (sec)');
ylabel('Mag Field (uT)');
legend('x','y','z')
%xlim([0,2000])

%%%Magnetic Field Norm
Bnorm = sqrt(BxBout.^2 + ByBout.^2 + BzBout.^2);
fig3 = figure();
set(fig3,'color','white')
plot(tout,Bnorm,'LineWidth',2)
xlabel('Time (sec)')
ylabel('Norm of Magnetic Field (T)')
grid on

%%%plot the magnetic field
fig5=figure();
set(fig5,'color','white');
plot(tout,BxBout/1e9,'b-','Linewidth',2);
hold on
grid on
plot(tout,ByBout/1e9,'r-','Linewidth',2);
hold on
plot(tout,BzBout/1e9,'g-','Linewidth',2);
xlabel('Time (sec)');
ylabel('Mag Field (uT) in Body Frame');
legend('x','y','z')
%xlim([0,2000])


%%%plot linear acceleration frame
fig6=figure();
set(fig6,'color','white');
plot(tout,lin_acc,'-','LineWidth',2)
grid on
xlabel('Time (sec)')
ylabel('Linear Acceleration')
legend('x','y','z')
%xlim([0,2000])
